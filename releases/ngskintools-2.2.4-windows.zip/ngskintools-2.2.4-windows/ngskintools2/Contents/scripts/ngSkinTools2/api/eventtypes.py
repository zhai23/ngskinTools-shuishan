from ngSkinTools2.signal import Event

tool_settings_changed = Event('tool_settings_changed')
